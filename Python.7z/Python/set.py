# Los conjuntos son inmutables
# Son desordenados, quiere decir que cuando se llama no se tiene certeza en el orden que los mostrara
# No son indexados
# No permite duplicados

vocales = {"A","E","I","O","U"}
print(len(vocales))
print(type(vocales))
# Para recorrer los conjuntos se usa IN
for i in vocales:
    print(vocales)
print("-------------")

for i in vocales:
    print(vocales)
print("-------------")

for i in vocales:
    print(vocales)

# tienen el metodo add y el metodo remove    
    
vocales.add("@")

for i in vocales:
    print(vocales)

# podemos remover

vocales.remove("@")    

for i in vocales:
    print(vocales)

# POP elimina cualquier dato al azar                                                                                                                                                                                                    
vocales.pop()

for i in vocales:
    print(vocales)


